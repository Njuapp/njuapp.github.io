function children = mutation(parent, V, M, datano)
    path = ['data', int2str(datano)];
    data = load(path);
    adj = data.adj;
    dist = data.dist;
    children = zeros([10, V+M]);
    
    len = parent(V+1);
    rm_list = check_rm(parent, dist, adj, datano);
    ex_list = check_ex(parent, dist, adj, datano);
    for ii = 1 : 20
        child = parent(1: V+M);
        if rand(1) <= 0.2
            % delete one adjustment node
            if size(rm_list,2) == 0
                continue
            end
            index = rm_list(randi(size(rm_list,2)));
            child(V+1) = child(V+1) - 1;
            if child(V+1) == 0
                continue;
            end
            child(index: len-1) = parent(index+1:len);
            child(len) = 0;
            children(ii, :) = child;
        else
            % exchange two adjacent adjustment node
            if size(ex_list,2) == 0
                continue
            end
            index = ex_list(randi(size(ex_list,2)));
            child(index) = parent(index+1);
            child(index+1) = parent(index);
            children(ii, :) = child;
        end
    end
end