function [delta_v, delta_h] = compute_err(adj, dist, link_path, cut)
    delta_v = 0;
    delta_h = 0;
    look_for = 1 - adj(link_path(cut));
    for i = cut : -1 : 2
        node = link_path(i);
        if look_for == adj(node)
            break;
        end
        if adj(node) == 1
            delta_v = delta_v + dist(link_path(i-1), node) * 0.001;
        else
            delta_h = delta_h + dist(link_path(i-1), node) * 0.001;
        end
    end
end