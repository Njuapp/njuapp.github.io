function [parent_1, parent_2] = randmarriage(N, parents)
    % Select the first parent
    parent_1 = round(N*rand(1));
    if parent_1 < 1
        parent_1 = 1;
    end
    % Select the second parent
    parent_2 = round(N*rand(1));
    if parent_2 < 1
        parent_2 = 1;
    end
    % Make sure both the parents are not the same. 
    while isequal(parents(parent_1,:),parents(parent_2,:))
        parent_2 = round(N*rand(1));
        if parent_2 < 1
            parent_2 = 1;
        end
    end
end