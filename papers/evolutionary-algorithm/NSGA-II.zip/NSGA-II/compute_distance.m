function [distance_matrix, soft_mat] = compute_distance(data)
X = data(:,1:2);
N = size(X,1);
dot_product = X * X';
distance_sq = repmat(diag(dot_product),[1,N]) + ...
    repmat(diag(dot_product)', [N,1]) - 2 * dot_product;
distance_matrix = sqrt(distance_sq);
normed_mat = distance_sq./max(distance_sq);
exp_mat = exp(-normed_mat);
soft_mat = exp_mat./sum(exp_mat);
end