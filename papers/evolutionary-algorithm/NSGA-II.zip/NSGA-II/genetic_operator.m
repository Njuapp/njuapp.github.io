function f  = genetic_operator(parent_chromosome, M, V, datano)

    %% function f  = genetic_operator(parent_chromosome, M, V, mu, mum, l_limit, u_limit)
    % 
    % This function is utilized to produce offsprings from parent chromosomes.
    % The genetic operators corssover and mutation which are carried out with
    % slight modifications from the original design. For more information read
    % the document enclosed. 
    %
    % parent_chromosome - the set of selected chromosomes.
    % M - number of objective functions
    % V - number of decision varaiables
    %
    % The genetic operation is performed only on the decision variables, that
    % is the first V elements in the chromosome vector. 

    pop = size(parent_chromosome, 1);
    if check_converge(parent_chromosome)
        f = parent_chromosome(1,:);
        return;
    end
    p = 1;
    % Flags used to set if crossover and mutation were actually performed. 
    was_crossover = 0;
    was_mutation = 0;
    if datano == 1
        theta = 30;
        sigma_ = 0.001;
        alpha1 = 25;
        alpha2 = 15;
        beta1 = 20;
        beta2 = 25;
        path_to_data = [pwd, '/data1.mat'];
    else
        theta = 20;
        sigma_ = 0.001;
        alpha1 = 20;
        alpha2 = 10;
        beta1 = 15;
        beta2 = 20;
        path_to_data = [pwd, '/data2.mat'];
    end
    data = load(path_to_data);
    adj = data.adj;
    dist = data.dist;
    soft = data.soft;

    for i = 1 : pop
        % With 90 % probability perform crossover
        if rand(1) < 0.9
            % Initialize the children to be null vector.
            [parent_1, parent_2] = randmarriage(pop, parent_chromosome);
            % Get the chromosome information for each randomnly selected
            % parents
            parent_1 = parent_chromosome(parent_1,:);
            parent_2 = parent_chromosome(parent_2,:);
            % Perform corssover with two chromosome.
            childlist = crossover(parent_1, parent_2, V, M, soft);
            % Make sure that the generated element is within the decision
            % space.

            % Set the crossover flag. When crossover is performed two children
            % are generate, while when mutation is performed only only child is
            % generated.
            was_crossover = 1;
            was_mutation = 0;
        % With 10 % probability perform mutation. Mutation is based on
        % polynomial mutation. 
        else
            % Select at random the parent.
            parent_3 = round(pop*rand(1));
            if parent_3 < 1
                parent_3 = 1;
            end
            % Get the chromosome information for the randomnly selected parent.
            parent_3 = parent_chromosome(parent_3,:);
            % Perform mutation on eact element of the selected parent.
            % Generate the corresponding child element.
            child_3 = mutation(parent_3, V, M, datano);
            % Make sure that the generated element is within the decision
            % space.

            % Set the mutation flag
            was_mutation = 1;
            was_crossover = 0;
        end
        % Keep proper count and appropriately fill the child variable with all
        % the generated children for the particular generation.
        if was_crossover
            child(p : p + size(childlist,1) - 1, :) = childlist;
            was_cossover = 0;
        elseif was_mutation
            child(p,:) = child_3(1,1 : M + V);
            was_mutation = 0;
            p = p + 1;
        end
    end
    f = child;

    

    function childlist = crossover(parent_1, parent_2, V, M, soft)
        all_cuts = overlaps(parent_1, parent_2, V, soft);
        len_1 = parent_1(V+1);
        len_2 = parent_2(V+1);
        childlist = zeros([2*size(all_cuts,1), V+2]);
        for kk =1 : size(all_cuts,1)
            cut_1 = all_cuts(kk, 1);
            cut_2 = all_cuts(kk, 2);
            child1 = zeros([1, V+M]);
            child2 = zeros([1, V+M]);
            assert(cut_1 + 1 + len_2 - cut_2 <= V);
            assert(cut_2 + 1 + len_1 - cut_1 <= V);
            child1(1:cut_1) = parent_1(1:cut_1);
            child1(cut_1 + 1 : cut_1 + len_2 - cut_2 + 1) = parent_2(cut_2 : len_2);
            child1(V+1) = cut_1 + len_2 - cut_2 + 1;
            child2(1:cut_2) = parent_2(1:cut_2);
            child2(cut_2 + 1 : cut_2 + len_1 - cut_1 + 1) = parent_1(cut_1 : len_1);
            child2(V+1) = cut_2 + len_1 - cut_1 + 1;
            childlist(2*kk - 1: 2*kk, :) = [child1;child2];
        end
    end

    
    function cut_pos = overlaps(parent_1, parent_2, V, soft)
        len_1 = parent_1(V+1);
        len_2 = parent_2(V+1);
        cut_pos = zeros([min(len_1 , len_2), 2]);
        cp = 0;
        map2 = zeros([V,1]);
        for k = 1 : len_2
            map2(parent_2(k)) = k;
        end
        for t = 1 : min(len_1 , len_2) 
            cut_1 = randi(len_1 - 2) + 1;
            c1 = parent_1(cut_1);
            min_cut_2 = max(2, len_2 - (V - cut_1) + 1);
            max_cut_2 = min(len_2-1, V - (len_1 - cut_1 + 1));
            delta_v = 0;
            delta_h = 0;
            % TODO: delta_v and delta_h computation
            look_for = 1 - adj(c1);
            for kk = cut_1 : -1:  2
                if adj(parent_1(kk)) == look_for
                    break;
                end
                if look_for == 1
                    delta_v = delta_v + dist(parent_1(kk), parent_1(kk-1)) * sigma_;
                else
                    delta_h = delta_h + dist(parent_1(kk), parent_1(kk-1)) * sigma_;
                end
            end
            % choose a GOOD cut node from [min, max] interval
            candidate = zeros([V, 1]);
            for n = min_cut_2 : max_cut_2
                c2 = parent_2(n);
                if adj(c2) == 1
                    if delta_v + dist(c1, c2) * sigma_ <= alpha1 ...
                        && delta_h + dist(c1, c2) * sigma_ <= alpha2
                        candidate(c2) = 1;
                    end
                elseif adj(c2) == 0
                    if delta_v + dist(c1, c2) * sigma_ <= beta1 ...
                        && delta_h + dist(c1, c2) * sigma_ <= beta2
                        candidate(c2) = 1;
                    end
                end
            end
            prob = (candidate == 1).* soft(:, parent_1(cut_1));
            if sum(prob) == 0 || sum(prob) == 0.0
                continue;
            end
            prob = prob / sum(prob);
            cut_2 = randsample(1: V, 1, true, prob);
            cut_2 = map2(cut_2);
            cp = cp + 1;
            cut_pos(cp, :) = [cut_1, cut_2];
        end
        cut_pos = cut_pos(1:cp, :);
    end 

end