clear ALL;
clc;
datano = 1;
pop = 20;
gen = 50;
for i = 1:100
    fprintf('==========%d==========\n', i);
    solution = nsga_2(pop, gen, datano);
    load(['best',int2str(datano)]);
    ia = size(solution, 2) - 3;
    it = size(solution ,2) - 2;
    if solution(ia) < best(ia) && solution(it) < best(it)
        best = solution;
        fprintf('Dataset %d has achieved best result:( %d, %f) [SEE: best%d.mat]\n',...
            datano, solution(ia), solution(it), datano);
        save(['best',int2str(datano)], 'best');
    end
end