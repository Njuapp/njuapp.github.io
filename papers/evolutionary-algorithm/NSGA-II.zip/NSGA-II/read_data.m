function points = read_data(path_to_xlsx)
sheet = xlsread(path_to_xlsx);
N = size(sheet,1);
points = sheet(:, 2:6);
points(1, 4) = -1;
points(N, 4) = -1;
end