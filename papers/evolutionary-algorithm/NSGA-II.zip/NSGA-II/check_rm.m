function feasible = check_rm(p, dist, adj, datano)
    V = size(adj, 1);
    len = p(V+1);
    feasible = zeros([1,V]);
    load('constraint');
    constraint = c(datano);
    fc = 0;
    err_v = 0;
    err_h = 0;
    for i = 2 : len - 1
        derr = dist(p(i-1),p(i+1)) * 0.001;
        if adj(p(i+1)) == 1
            if err_v + derr <= constraint.alpha1...
                    && err_h + derr <= constraint.alpha2
                fc = fc + 1;
                feasible(fc) = i;
            end
        elseif adj(p(i+1)) == 0
            if err_v + derr <= constraint.beta1...
                    && err_h + derr <= constraint.beta2
                fc = fc + 1;
                feasible(fc) = i;
            end
        else
            if max(err_v,err_h) + derr <= constraint.theta
                fc = fc + 1;
                feasible(fc) = i;
            end
        end
        err_v = err_v + dist(p(i-1),p(i)) * 0.001;
        err_h = err_h + dist(p(i-1),p(i)) * 0.001;
        if adj(i) == 1
            err_v = 0;
        else
            err_h = 0;
        end
    end
    feasible = feasible(1:fc);
end