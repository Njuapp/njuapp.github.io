%% Initialize the population
% Population is initialized with random values which are within the
% specified range. Each chromosome consists of the decision variables. Also
% the value of the objective functions, rank and crowding distance
% information is also added to the chromosome vector but only the elements
% of the vector which has the decision variables are operated upon to
% perform the genetic operations like corssover and mutation.
function chrosomes = initialize_variables(pop, V, datano)
chrosomes = zeros([pop, V + 2]);
cnt = 1;
while cnt <= pop
[chrosome, flag] = initialization(datano);
if flag == 1
    chrosomes(cnt,:) = chrosome;
    cnt = cnt + 1;
end
end
