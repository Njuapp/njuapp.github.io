function feasible = check_ex(p, dist, adj, datano)
    V = size(adj, 1);
    len = p(V+1);
    feasible = zeros([V, 1]);
    load('constraint');
    constraint = c(datano);
    fc = 0;
    err_v = 0;
    err_h = 0;
    for i = 2 : len - 2
        derr1 = dist(p(i-1),p(i+1)) * constraint.sigma;
        derr2 = dist(p(i), p(i+1)) * constraint.sigma;
        if adj(p(i+1)) == 1
            if err_v + derr1 > constraint.alpha1...
                    || (err_h + derr1 > constraint.alpha2)
                err_v = 0;
                err_h = err_h + dist(p(i-1),p(i)) * constraint.sigma;
                continue;
            else
                err_v_tmp = 0;
                err_h_tmp = err_h + derr1;
            end
        else
            if err_v + derr1 > constraint.beta1...
                    || (err_h + derr1 > constraint.beta2)
                err_v = err_v + dist(p(i-1),p(i)) * constraint.sigma;
                err_h = 0;
                continue;
            else
                err_v_tmp = err_v + derr2;
                err_h_tmp = 0;
            end
        end
        if adj(p(i)) == 1
            if err_v_tmp + derr2 > constraint.alpha1...
                    || (err_h_tmp + derr2 > constraint.alpha2)
                err_v = 0;
                err_h = err_h + dist(p(i-1),p(i)) * constraint.sigma;
                continue;
            else
                err_v = 0;
                err_h = err_h_tmp + derr2;
            end
        else
            if err_v_tmp + derr2 > constraint.beta1...
                    || (err_h_tmp + derr2 > constraint.beta2)
                err_v = err_v + dist(p(i-1),p(i)) * constraint.sigma;
                err_h = 0;
                continue;
            else
                err_v = err_v_tmp + derr2;
                err_h = 0;
            end
        end
        fc = fc + 1;
        feasible(fc) = i;
    end
    feasible = feasible(1:fc);
end