function [adults,valid] = survive(children, dataset_no)
  if dataset_no == 1
    constraint = [30 0.001 25 15 20 25];
    path_to_xlsx = [pwd, '/data1.xlsx'];
  else
    constraint = [20 0.001 20 10 15 20];
    path_to_xlsx = [pwd, '/data2.xlsx'];
  end
  number = size(children, 1);
  sigma_ = constraint(2);
  theta = constraint(1);
  valid = ones([number,1]);
  alpha1 = constraint(3);
  alpha2 = constraint(4);
  beta1 = constraint(5);
  beta2 = constraint(6);
  data = read_data(path_to_xlsx);
  V = size(data,1);
  [distance, ~] = compute_distance(data);

  for c = 1: number
    child = children(c, :);
    child(V+2) = 0;
    len = child(V+1);
    cnt = zeros([1, V]);
    cnt(1) = 1;
    cnt(V) = 1;
    delta_v = 0;
    delta_h = 0; 
    % check whether any node has been used more than once
    % check whether the error has been above the threshold
    id = 1;
    for i = 2 : len
      newid = child(i);
      child(V+2) = child(V+2) + distance(id, newid);
      
      cnt(newid) = cnt(newid) + 1;
      if cnt(id) > 1
        valid(c) = 2;
        break;
      end
      
      delta_v = delta_v + distance(id, newid) * sigma_;
      delta_h = delta_h + distance(id, newid) * sigma_;
      if data(newid, 4) == 1
        % vertically adjust
        if delta_v > alpha1 || delta_h > alpha2
          valid(c) = 0;
          break;
        end
        delta_v = 0;
      elseif data(newid, 4) == 0
        % horizontally adjust
        if delta_v > beta1 || delta_h > beta2
          valid(c) = 0;
          break;
        end
        delta_h = 0;
      else
        assert(i == len, '%d %d\n' ,i, len);
        if delta_v > theta || delta_h > theta
          valid(c) = -1;
          break;
        end
      end

      id = newid;
    end
    children(c, V+2) = child(V+2);
  end

  adults = children(valid == 1, :);
end