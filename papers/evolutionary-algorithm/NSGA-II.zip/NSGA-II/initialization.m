function [chrosome, flag] = initialization(datano)
if datano == 1
    constraint = [30 0.001 25 15 20 25];
    path = 'data1';
else
    constraint = [20 0.001 20 10 15 20];
    path = 'data2';
end

data = load(path);
distance = data.dist;
soft = data.soft;
adj = data.adj;
V = size(adj,1);
mask = ones([V,1]);
id = 1;
sigma = constraint(2);
delta_v = 0;
delta_h = 0;
chrosome = zeros([1, V + 2]);
err_list = zeros([V, 4]);
cnt = 0;
while id ~= V
    chrosome(V+1) = chrosome(V+1) + 1;
    chrosome(chrosome(V+1)) = id;
    mask(id) = 0;
    newid = choose_next(id, distance, mask, soft(:,V), adj, delta_v, delta_h, constraint);
    if newid == id
        flag = 0;
        return;
    end
    dist = distance(id, newid) * sigma;
    delta_v = delta_v + dist;
    delta_h = delta_h + dist;
    cnt = cnt + 1;
    err_list(cnt, 1:2) = [delta_v, delta_h];
    if adj(newid) == 1
        % vertically adjust
        err_list(cnt, 3:4) = [constraint(3), constraint(4)];
        delta_v = 0;
    elseif adj(newid) == 0
        % horizontally adjust
        err_list(cnt, 3:4) = [constraint(5), constraint(6)];
        delta_h = 0;
    end
    assert(newid <= V && id <= V, '%d, %d\n', newid, id);
    chrosome(V+2) = chrosome(V+2) + distance(newid, id);
    id = newid;
end
chrosome(V+1) = chrosome(V+1) + 1;
chrosome(chrosome(V+1)) = V;
number_of_node = chrosome(V+1);
cost = chrosome(V+2);
fprintf('One path costs %f m and traverses %d adjustment nodes\n', cost, number_of_node - 2);
fprintf('A - ');
for i = 2: number_of_node
    fprintf('%d - ', chrosome(i));
end
fprintf('B\n');
flag = 1;
end