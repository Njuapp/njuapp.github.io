function converged = check_converge(parents)
    N = size(parents,1);
    converged = 1;
    for i = 2: N
        if ~isequal(parents(1,:),parents(i,:))
            converged = 0;
        end
    end
end