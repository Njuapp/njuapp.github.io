function next_id = choose_next(id, distance, mask, softmax_B, adj, delta_v, delta_h, constraint)
%% function [next_id, delta_v, delta_h] = choose_next(id, distance, mask, softmax, delta_v, delta_h, constraint)
% id: current id
% distance: distance matrix
% mask: the remaining node index
% softmax_B: the softmaxed probability w.r.t B node
% delta_v: current error (vertically)
% delta_h: current error (horizontally)
% constraint: a 6-dim vector, resp. theta, sigma, alpha1, alpha2,
%   beta1, beta2

%% Determine the candidate list.
N = size(distance, 1);
valid = zeros([N,1]);
theta = constraint(1);
sigma = constraint(2);
alpha1 = constraint(3);
alpha2 = constraint(4);
beta1 = constraint(5);
beta2 = constraint(6);
for ii = 1:N
    if mask(ii) == 0
        continue;
    end
    dist = distance(ii, id);
    if adj(ii) == 1
        % vertically adjustment
        % alpha1, alpha2
        if (delta_v + dist * sigma <= alpha1) && (delta_h + dist * sigma <= alpha2)
            valid(ii) = 1;
        end
    elseif adj(ii) == 0
        % horizontally adjustment
        % beta1, beta2
        if (delta_v + dist * sigma <= beta1) && (delta_h + dist * sigma <= beta2)
            valid(ii) = 1;
        end
    else
        % the destination point
        if (delta_v + dist * sigma <= theta) && (delta_h + dist * sigma <= theta)
            valid(ii) = 1;
        end
    end
end
%% Softmax it, then randomly choose a postfix node
if sum(valid) == 0
    next_id = id;
    return;
end
prob = valid .* softmax_B;
prob = prob / sum(prob);
next_id = randsample(1:N, 1, true, prob);
end